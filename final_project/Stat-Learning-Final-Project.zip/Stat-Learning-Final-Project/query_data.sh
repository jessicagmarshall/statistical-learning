#!/bin/bash

clear

echo "Running node processData.js \#whywomendontreport \#notokay \#masculinitysofragile \#whyistayed \#rapecultureiswhen \#webelieveyou \#tihty \#tilithappenstoyou \#askingforit \#thehuntingground \#rapeculture \#listentosurvivors \#thingslongerthanbrockturnersrapesentence \#endrapeculture \#stanfordrapist \#sexualviolence \#emilydoe"

node processData.js \#whywomendontreport \#notokay \#masculinitysofragile \#whyistayed \#rapecultureiswhen \#webelieveyou \#tihty \#tilithappenstoyou \#askingforit \#thehuntingground \#rapeculture \#listentosurvivors \#thingslongerthanbrockturnersrapesentence \#endrapeculture \#stanfordrapist \#sexualviolence \#emilydoe
